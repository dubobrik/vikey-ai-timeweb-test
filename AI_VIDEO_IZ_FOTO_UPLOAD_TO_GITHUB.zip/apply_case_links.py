from pathlib import Path
root = Path('.')

def patch(path, needle, replacement):
    p = root / path
    content = p.read_text(encoding='utf-8')
    if replacement in content:
        print('Already present:', path)
        return
    if content.count(needle) != 1:
        raise RuntimeError(f'Anchor not unique for {path}: {content.count(needle)}')
    p.write_text(content.replace(needle, replacement), encoding='utf-8')

patch('src/routes/index.tsx',
      'const portfolio = [',
      'const portfolio = [\n  {\n    title: "AI-видео из исходных фотографий",\n    tag: "AI-видео / Исходник → результат",\n    desc: "Два реальных исходных изображения превращены в короткие AI-ролики. Кейс показывает формат «исходник → результат».",\n    image: aiVideoPhotoCaseImage,\n    caseHref: "/case-ai-video-iz-foto/",\n  },')
patch('src/routes/index.tsx',
      'import heroAsset from "@/assets/vikey-hero.jpg";',
      'import heroAsset from "@/assets/vikey-hero.jpg";\nimport aiVideoPhotoCaseImage from "@/assets/ai-video-result-01-poster.webp";')
patch('src/routes/ai-video-dlya-biznesa.tsx',
      '        <Section id="formats" eyebrow="Форматы" title="Какие AI-видео можно создать для бизнеса">',
      '''        <Section eyebrow="Реальный кейс" title="AI-видео из фотографии">
          <p className="max-w-4xl leading-relaxed text-muted-foreground">Два примера превращения статичных исходных фотографий в короткие AI-ролики. Сравните оригиналы с результатами.</p>
          <a href="/case-ai-video-iz-foto/" className="mt-5 inline-flex min-h-11 items-center font-semibold text-neon">Посмотреть кейс →</a>
        </Section>
        <Section id="formats" eyebrow="Форматы" title="Какие AI-видео можно создать для бизнеса">''')
patch('src/routes/ai-kreativy-dlya-biznesa.tsx',
      '   <Section title="AI-креатив или AI-видео — что выбрать?">',
      '''   <Section title="Из статичного изображения — в AI-видео"><p className="max-w-4xl leading-relaxed text-muted-foreground">Если готовый визуал нужно показать в движении, посмотрите реальный кейс создания двух AI-видео на основе исходных фотографий.</p><a href="/case-ai-video-iz-foto/" className="mt-5 inline-flex min-h-11 items-center font-semibold text-neon">Как фото превращается в AI-видео →</a></Section>
   <Section title="AI-креатив или AI-видео — что выбрать?">''')
patch('public/sitemap.xml',
      '</urlset>',
      '''  <url>
    <loc>https://chelovek-neiroset.ru/case-ai-video-iz-foto/</loc>
  </url>
</urlset>''')
sitemap=(root/'public/sitemap.xml').read_text(encoding='utf-8')
assert sitemap.count('<loc>')==16, f'Expected 16 URLs, got {sitemap.count("<loc>")}'
print('Linking and sitemap complete, 16 URL entries')
