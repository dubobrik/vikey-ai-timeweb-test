from pathlib import Path
p = Path('src/routes/index.tsx')
s = p.read_text(encoding='utf-8')
a = 'const InteractiveVLogo = lazy(() => import("@/components/InteractiveVLogo"));'
assert a not in s, 'The logo was already inserted'
anchor = 'function Hero() {'
assert s.count(anchor) == 1, 'Hero function not uniquely found'
s = s.replace(anchor, a + '\n\n' + anchor, 1)
needle = '''            <a href="#contact" className="rounded-lg bg-gradient-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-glow transition hover:opacity-95">
              Обсудить задачу
            </a>'''
assert s.count(needle) == 1, 'Hero CTA not uniquely found'
replacement = needle + '''
            <Suspense fallback={<div className="h-28 w-28 shrink-0" aria-hidden="true" />}>
              <InteractiveVLogo />
            </Suspense>'''
s = s.replace(needle, replacement, 1)
p.write_text(s, encoding='utf-8')
print('Inserted lazy 3D logo immediately after Hero contact CTA')
