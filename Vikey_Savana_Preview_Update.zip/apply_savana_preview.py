from pathlib import Path
p=Path('src/routes/index.tsx')
s=p.read_text(encoding='utf-8')
old='import savanaSitePreview from "@/assets/savana-site-preview.webp";'
new='import savanaSitePreview from "@/assets/savana-site-preview-2026.webp";'
assert s.count(old)==1,'Expected exactly one original preview import'
assert s.count('image: savanaSitePreview,')==1,'Portfolio card does not match expected structure'
assert 'viewHref: "https://www.savanadivik.ru/"' in s,'Expected updated website URL'
p.write_text(s.replace(old,new),encoding='utf-8')
print('Updated only the savana preview asset import')
